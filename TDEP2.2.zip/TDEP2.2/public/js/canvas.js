let url = "/api";

fetch(url)
    .then(res => res.json())
    .then(dataTime => drawStuff(dataTime)) 


const canvas = document.getElementById('canvas1');
const ctx = canvas.getContext('2d')

canvas.width=900;
canvas.height=400;

let player_x1 = 28;
let player_x2 = 103;
let player_x3 = 178;
let player_x4 = 253;

let player_x5 = 328;
let player_x6 = 403;
let player_x7 = 478;
let player_x8 = 553;

let player_x9 = 628;
let player_x10 = 703;
let player_x11 = 778;
let player_x12 = 853;

let player_y = 400 - 20;
let width = 20;
let height = 20;

const drawStuff = () => {
    ctx.clearRect(0,0,600,400)

    ctx.fillStyle = '#ff1500';
    ctx.fillRect(player_x1, player_y, width, height);

    ctx.fillStyle = '#ffe933';
    ctx.fillRect(player_x2, player_y, width, height);

    ctx.fillStyle = '#0000FF';
    ctx.fillRect(player_x3, player_y, width, height);

    ctx.fillStyle = '#6bff33';
    ctx.fillRect(player_x4, player_y, width, height);

    ctx.fillStyle = '#ff1500';
    ctx.fillRect(player_x5, player_y, width, height);

    ctx.fillStyle = '#ffe933';
    ctx.fillRect(player_x6, player_y, width, height);

    ctx.fillStyle = '#0000FF';
    ctx.fillRect(player_x7, player_y, width, height);

    ctx.fillStyle = '#6bff33';
    ctx.fillRect(player_x8, player_y, width, height);

    ctx.fillStyle = '#ff1500';
    ctx.fillRect(player_x9, player_y, width, height);

    ctx.fillStyle = '#ffe933';
    ctx.fillRect(player_x10, player_y, width, height);

    ctx.fillStyle = '#0000FF';
    ctx.fillRect(player_x11, player_y, width, height);

    ctx.fillStyle = '#6bff33';
    ctx.fillRect(player_x12, player_y, width, height);

}

const loop = () => {
    drawStuff();
}

setInterval(loop, 10000);