// const bcrypt = require('bcryptjs')

// exports.PasswordSalting = (req, res) => {
//     let salt = bcrypt.genSaltSync(10)
//     let has = bcrypt.hashSync()
// }